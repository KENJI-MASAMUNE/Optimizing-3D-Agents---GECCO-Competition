"""
Task-specific fitness functions over a COG body-recording path. Owner: Vanessa Rampedi

Deliberately has ZERO dependency on framspy/FramsticksLib -- just numpy -- so these can be
unit-tested on every machine and in CI regardless of whether the real simulator is
installed. `competition_lib.py` (which DOES depend on framspy) imports these; nothing here
imports it back.
"""
from __future__ import annotations

import math

import numpy as np

# Below this many recorded COG steps, several of these fitness definitions become
# mathematically trivial rather than meaningful -- see _warn_if_degenerate() below.
MIN_TRAJECTORY_STEPS = 10

# Fixed distance (world units) the desired straight-line path travels along +x, starting
# from wherever the creature actually begins. Tune this to whatever displacement scale is
# realistic for your creatures' typical lifespan/Energy0 -- too large and even good
# locomotion scores near 0; too small and mediocre locomotion saturates near 1.
TARGET_LINE_DISTANCE = 10.0

_warned_short_trajectory = False


def _warn_if_degenerate(path: np.ndarray, task: str) -> None:
    global _warned_short_trajectory
    if len(path) < MIN_TRAJECTORY_STEPS and not _warned_short_trajectory:
        print(
            f"[task_fitness] WARNING: trajectory for task '{task}' has only {len(path)} "
            f"recorded steps (< {MIN_TRAJECTORY_STEPS}). Fitness values are likely "
            "meaningless/trivial. Check Energy0 in your .sim settings to increase "
            "creature lifespan. This warning only prints once per process."
        )
        _warned_short_trajectory = True


def extract_cog_trajectory(raw_path) -> np.ndarray:
    """Normalises `data->bodyrecording` into a plain (n_steps, 3) COG-only array,
    regardless of the `STORE_ALL_PART_COORDS` setting in `recording-body-coords.sim`:

    - STORE_ALL_PART_COORDS=0 (recommended -- see FramsticksLibCompetition.py's own
      docstring): each step is already just `[cogx, cogy, cogz]` -> shape (n_steps, 3).
    - STORE_ALL_PART_COORDS=1 (verbose): each step is
      `[[cogx,cogy,cogz], [p1x,p1y,p1z], ...]` -> shape (n_steps, n_parts+1, 3), with the
      COG always at index 0 of the second axis (per the .sim file's own comment: "after
      the COG, the list of coordinates of all Parts follows").
    """
    arr = np.array(raw_path)
    if arr.ndim == 3:  # verbose format: (n_steps, n_parts+1, 3) -> take COG (index 0)
        return arr[:, 0, :]
    return arr  # already (n_steps, 3)


def _heading_vector(heading_deg: float) -> np.ndarray:
    """Unit vector in the x-y plane for a desired travel heading (0 deg = +x, 90 deg = +y).
    Used by worlds with `target_heading_deg` (deterministic stand-in for a rotated start)."""
    h = math.radians(heading_deg)
    return np.array([math.cos(h), math.sin(h), 0.0])


def fitness_straight_line_cog(path: np.ndarray, target_heading_deg: float = 0.0) -> float:
    """1.0 / RMSE of COG coordinates vs. a FIXED straight line: starting at the creature's
    actual starting position, travelling TARGET_LINE_DISTANCE along +x.

    IMPORTANT DESIGN NOTE: the target line is fixed/external, NOT fit from the creature's
    own start/end points. An earlier version defined target = interpolation between the
    creature's own start and end position -- which meant a creature that never moved at
    all (start == end) trivially scored a perfect 1.0 (RMSE=0 by construction), identical
    to a creature that travelled flawlessly toward a real goal. That made this fitness
    function unable to distinguish "did nothing" from "did great," which is a serious bug
    for a fitness landscape NSGA-II is supposed to climb. This version can't have that
    problem: a stationary creature is meaningfully far from where the fixed target line
    says it should be by the end of the episode, and scores accordingly low.
    """
    path = extract_cog_trajectory(path)
    _warn_if_degenerate(path, "straight_line_cog")
    start = path[0]
    t = np.linspace(0, 1, len(path))
    direction = TARGET_LINE_DISTANCE * _heading_vector(target_heading_deg)
    target = start[None, :] + t[:, None] * direction[None, :]
    rmse = math.sqrt(float(np.mean(np.sum((path - target) ** 2, axis=1))))
    return 1.0 / (1.0 + rmse)


SINUSOID_AMPLITUDE = 0.1   # A in z(t) = c + A*sin(t/100): the competition's example shape
SINUSOID_PERIOD_DIV = 100.0


def fitness_sinusoidal_bounce(path: np.ndarray, **_ignored) -> float:
    """How well the COG height follows the oscillation A*sin(t/100) (A = 0.1, the
    competition's example "0.5 + 0.1*sin(t/100.0)"), scored as 1 / (1 + RMSE / A).

    REVISED (Oct 2026, after Phase 1) -- the previous version, 1/(1 + mean|z - target|)
    against the ABSOLUTE target 0.5 + 0.1*sin(t/100), had a ceiling effect: a creature that
    simply holds its COG still at height 0.5 already scores 1/(1 + 0.0637) = 0.940, and a
    perfect follower only 1.0. In Phase 1 every variant and encoding converged to exactly
    that "stand still at 0.5" solution (mean 0.940, std ~0.001), so the task could not
    separate algorithms. It also rewarded raised terrain / floating in water in Phase 3
    worlds, because the target height was absolute.

    Now:
      * the constant offset c is fitted (least squares) instead of fixed at 0.5, so the
        score measures the OSCILLATION, independent of body height, terrain or water;
      * the error is divided by the amplitude A, so the scale is meaningful:
            perfect follower                      -> 1.0
            stationary creature (any height)      -> 1/(1 + 1/sqrt(2)) ~= 0.586
            right amplitude, opposite phase       -> 1/(1 + sqrt(2))   ~= 0.414
        i.e. anything above ~0.59 means the agent genuinely oscillates in time with the target.
    """
    path = extract_cog_trajectory(path)
    _warn_if_degenerate(path, "sinusoidal_bounce")
    z = path[:, 2]
    t = np.arange(len(path))
    shape = SINUSOID_AMPLITUDE * np.sin(t / SINUSOID_PERIOD_DIV)
    residual = z - shape
    residual = residual - residual.mean()          # best-fitting constant offset c
    rmse = float(np.sqrt(np.mean(residual ** 2)))
    return 1.0 / (1.0 + rmse / SINUSOID_AMPLITUDE)


def fitness_velocity_forward(path: np.ndarray, target_heading_deg: float = 0.0) -> float:
    """Net forward displacement of the COG along the target heading (default +x) over the
    episode. A stationary creature scores exactly 0.0, not a false maximum."""
    path = extract_cog_trajectory(path)
    _warn_if_degenerate(path, "velocity_forward")
    return float(np.dot(path[-1] - path[0], _heading_vector(target_heading_deg)))


def fitness_jump_height(path: np.ndarray, **_ignored) -> float:
    """Peak vertical (z-axis) displacement of the COG above its starting height. Already
    correctly defined -- a stationary creature scores exactly 0.0."""
    path = extract_cog_trajectory(path)
    _warn_if_degenerate(path, "jump_height")
    return float(np.max(path[:, 2] - path[0, 2]))


# ---------------------------------------------------------------- competition examples
# The organisers' public example functions (framspy FramsticksLibCompetition.TEST_FUNCTION
# 3, 4, 5). Not part of our four proxy tasks; registered so results can be compared directly
# with published numbers (Brassat 2026 thesis, Table 5) when run under the reference settings
# (Energy0 10000, 100k evaluations) -- see configs/competition_config.yaml.
def fitness_comp_distance(path: np.ndarray, **_ignored) -> float:
    """TEST_FUNCTION 3: Euclidean distance between the COG at birth and at death."""
    path = extract_cog_trajectory(path)
    return float(np.linalg.norm(path[0] - path[-1]))


def fitness_comp_tall_runner(path: np.ndarray, **_ignored) -> float:
    """TEST_FUNCTION 4: distance travelled x mean height of the COG above ground."""
    path = extract_cog_trajectory(path)
    return float(np.linalg.norm(path[0] - path[-1]) * np.mean(np.maximum(0, path[:, 2])))


def fitness_comp_rising_cog(path: np.ndarray, **_ignored) -> float:
    """TEST_FUNCTION 5: COG height should rise linearly from 0 to 10 over the lifespan;
    1000 - RMSE (offset keeps it positive)."""
    path = extract_cog_trajectory(path)
    return float(1000 - np.linalg.norm(np.linspace(0, 10, len(path), endpoint=True) - path[:, 2]) / np.sqrt(len(path)))


TASK_FITNESS_FUNCTIONS = {
    "comp_distance": fitness_comp_distance,
    "comp_tall_runner": fitness_comp_tall_runner,
    "comp_rising_cog": fitness_comp_rising_cog,
    "straight_line_cog": fitness_straight_line_cog,
    "sinusoidal_bounce": fitness_sinusoidal_bounce,
    "velocity_forward": fitness_velocity_forward,
    "jump_height": fitness_jump_height,
}
